# bmi

Flutter Apps Challenge #3

## Getting Started

BMI Calculator